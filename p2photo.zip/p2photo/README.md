##### Documentation regarding the available P2Photo-webServer endpoints
##### Summarized below:

* Signup
* Login
* Logout
* Find Users
* New Catalog
* New Catalog Slice Identifier
* New Catalog Member
* View Catalog Members
* View Catalog
* View Catalog Details

All endpoint parameters are specified either has URL params or Data params.
If one or both sections are not available, then the endpoint accepts no such params. 

This documentation also includes a generalized error session, most endpoints can throw all or part of these errors.
Errors specific to an endpoint are listed on its corresponding section

--------------------------------

**Signup**
----

* **URL**

    /signup

* **Method:**

    `POST`
    
* **Data Params**
    ```
    {
        "username" : "a_username",
        "password" : "a_password"
    }
     ```
* **Success Response:**
  
    **Code:** 200  
    
    **Content:**
    ```
    {
        "operation" : "signup",
        "code" : 200,
        "message" : "OK",
    }
    ```
 
* **Error Response:**

    **Code:** 422 
    
    **Content:**
    ```
    {
        "operation" : "signup",
        "code" : 422,
        "message" : "unprocessable entity",
        "reason" : "invalid calleeUsername - user already exists"
    }
    ```
        
--------------------------------

**Login**
----

* **URL**

   /login

* **Method:**

    `POST`
   
* **Data Params**
   ```
   {
        "username" : "a_username",
        "password" : "a_ciphered_password"
   }
    ```
* **Success Response:**
 
    **Code:** 200  
    
    **Content:**
    ```
    {
        "operation" : "login",
        "code" : 200,
        "message" : "OK"
    }
    ```

* **Error Response:**

    **Code:** 401  
    
    **Content:**
    ```
    {
        "code" : 401,
        "message" : "unauthorized",
        "reason" : "invalid password - wrong credentials"
    }
    ```
       
--------------------------------

**Logout**
----
  
* **URL**

    /logout/{calleeUsername}

* **Method:**

    `DELETE`
  
* **URL Params**

    ***Required:***
    ```
    calleeUsername=[string]
    ```
    
* **Success Response:**

    **Code:** 200  
    
    **Content:**
    ```
    {
       "operation" : "logout",
       "code" : 200,
       "message" : "OK"
    }
    ```
 
 * **Notes:**
 
    If the calleeUsername and the cookie value match the user will be logged out and the sessionId received on login will be invalidated
 
--------------------------------  
    
 **Find Users**
 ----
 
* **URL**
 
    /findUsers
     
* **Method:**
    
    `GET`
  
* **URL Params**

    ***Required:***
    
    searchPattern=[string]
    bringCatalogs=[string] ("false" to retrieve only matching users, anything else will bring each user's catalogs)
    calleeUsername=[string]

 * **Success Response:**
  
    **Code:** 200  
    
    **Content:**
    ```
    {
         "operation" : "findUsers", 
         "result" : [
             {
                 "a_user" : [ "a_catalog_id", "another_catalog_id"],
                 "another_user" : [ ]          
             }
         ]
         "code" : 200,
         "message" : "OK"
    }
    ```
        
--------------------------------

**New Catalog**
----

* **URL**

    /newCatalog

* **Method:**

    `POST`
 
* **Data Params**
   ```
   {
        "catalogTitle" : "a_name",
        "catalogFileGoogleId" : "google_drive_file_id",
        "calleeUsername" : "requesting_user_username"
   }
    ```
* **Success Response:**
 
  **Code:** 200  
  
  **Content:**
   ```
   {
        "operation" : "newCatalog", 
        "code" : 200,
        "message" : "OK"
   }
   ```

--------------------------------

**New Catalog Slice Identifier**
----

* **URL**

   /newCatalogSlice/{catalogId}

* **Method:**

    `PUT`
 
*  **URL Params**

   catalogId=[string]
   
* **Data Params**
   ```
   {
        "parentFolderGoogleId" : "a_google_drive_file_id",
        "catalogFileGoogleId" : "another_google_drive_file_id",
        "webContentLink" : "a_url_for_a_catalog.json_file_hosted_on_google_drive"
        "calleeUsername" : "requesting_user_username"
   }
    ```
* **Success Response:**
 
  **Code:** 200  
  
  **Content:**
   ```
   {
        "operation" : "newCatalogSlice", 
        "code" : 200,
        "message" : "OK"
   }
   ```

* **Error Response:**

   **Code:** 403  
   
   **Content:**
   ```
   {
        "operation" : "newCatalogSlice",
        "code" : 403,
        "message" : "forbidden",
        "reason" : "invalid membership - user does not belong to referenced catalog"
   }
   ```
   
--------------------------------

**New Catalog Member**
----
  
* **URL**

    /newCatalogMember

* **Method:**

    `POST`

* **Data Params**
    ```
    {
      "catalogId" :  "13125618841614",
      "newMemberUsername" : "new_member_username",
      "calleeUsername" : "requesting_user_username"
    }
    ```
    
* **Success Response:**

    **Code:** 200  
    
    **Content:**
    ```
    {
       "operation" : "newCatalogMember", 
       "code" : 200,
       "message" : "OK"
    }
    ```
      
--------------------------------

**View Catalog Members**
----
   
* **URL**

    /viewCatalogMembers

* **Method:**

    `GET`
 
* **URL Params**

    ***Required:***
    
    catalogId=[string]
    calleeUsername=[string]
 
* **Success Response:**
 
    **Code:** 200  
    
    **Content:**
    ```
    {
        "operation" : "listCatalogMembers", 
        "result" : [ "a_username", "another_username" ],
        "code" : 200,
        "message" : "OK"
    }
    ```
    
 --------------------------------
 
 **View Catalog**
 ----
    
* **URL**
 
    /viewCatalog
 
* **Method:**
 
    `GET`
  
* **URL Params**
     
     ***Required:***
     
     catalogId=[string]
     calleeUsername=[string]

* **Success Response:**
  
    **Code:** 200  
    **Content:**
    ```
    {
         "operation" : "viewCatalog", 
         "result" : [ "a_google_drive_file_id", "another_google_drive_file_id" ],
         "code" : 200,
         "message" : "OK"
    }
    ```
 
 --------------------------------
  
  **View Catalog Details**
  ----
     
 * **URL**
  
     /viewCatalogDetails
  
 * **Method:**
  
     `GET`
   
 * **URL Params**
      
      ***Required:***
      
      catalogId=[string]
      calleeUsername=[string]
 
 * **Success Response:**
   
     **Code:** 200  
     **Content:**
     ```
     {
          "operation" : "viewCatalogDetails", 
          "result" : "catalog_title",
          "code" : 200,
          "message" : "OK"
     }
     ```
 
  --------------------------------
 
 **General P2Photo API Errors**
 ----
 
* **Unauthorized**

    **Code:** 403
    
     ```
     {
          "operation" : "operationName",
          "code" : 403,
          "message" : "unauthorized",
          "reason" : "invalid sessionId - does not seem to belong to this user, please login again"
     }
     ```
          
* **Service Unavailable**

    **Code:** 503
    
     ```
     {
          "operation" : "operationName",
          "code" : 503,
          "message" : "service unavaible",
          "reason" : "no service - server could not connect to databases, try again later."
     }
     ```
     
* **Internal Server Error**
    
    **Code:** 500
    
    ```
    {
       "operation" : "operationName",
       "code" : 500,
       "message" : "internal server error",
       "reason" : "unexpected SQL error - try again later, if the problem persists send an email at support@p2photo.com"
    }
    ```
    
    OR other 500 HTTP Status code variants with default responses, which include an "error" field
    
    **Code:** 500
    
    ```
    {
       "code" : 500,
       "message" : "internal server error",
       "error" : "some default message"
    }
    ```
      
* **Internal Server Error**  
  
    **Code:** 404
    
    ```
    {
       "operation" : "operationName",
       "code" : 404,
       "message" : "resource not found",
       "reason" : "invalid {resourceName} - does not exist in p2photo databases"
    }
     
    resourceName = catalogId || sessionId || calleeUsername
    ```