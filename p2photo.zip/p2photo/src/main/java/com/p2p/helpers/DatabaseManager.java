package com.p2p.helpers;

import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;

@SuppressWarnings("Duplicates")
public class DatabaseManager
{
    private static String selectQuery(String queryName) {
        String userExistsQ = "SELECT username FROM users WHERE username = ? LIMIT 1";
        String catalogExistsQ = "SELECT catalog_id FROM memberships WHERE catalog_id = ?  LIMIT 1";
        String membershipExistsQ = "SELECT * FROM memberships WHERE catalog_id = ? AND username = ? LIMIT 1";
        switch (queryName) {
            case "username":
                return userExistsQ;
            case "catalog":
                return catalogExistsQ;
            case "membership":
                return membershipExistsQ;
            default:
                return null;
        }
    }

    public static Connection getJDBCConnection() throws URISyntaxException, SQLException {
        URI dbUri = new URI(System.getenv("DATABASE_URL"));

        String username = dbUri.getUserInfo().split(":")[0];
        String password = dbUri.getUserInfo().split(":")[1];
        String dbUrl =
                "jdbc:postgresql://" + dbUri.getHost() + ':' + dbUri.getPort() + dbUri.getPath() + "?sslmode=require";

        return DriverManager.getConnection(dbUrl, username, password);
    }

    public static BigDecimal getEpochSecondNow()
    {
        return new BigDecimal(Instant.now().getEpochSecond());
    }

    private static void existsQuery(String queryName, Object lookUpTarget, Connection connection)
            throws NotFoundException, SQLException {

        String query = selectQuery(queryName);
        PreparedStatement statement = connection.prepareStatement(query);

        if (lookUpTarget instanceof String) {
            statement.setString(1, (String)lookUpTarget);
        }
        else if (lookUpTarget instanceof BigDecimal){
            statement.setBigDecimal(1, (BigDecimal)lookUpTarget);
        }
        else if (lookUpTarget instanceof HashMap) {
            statement.setBigDecimal(1, new BigDecimal((String)((HashMap)lookUpTarget).get("catalogId")));
            statement.setString(2, (String)((HashMap)lookUpTarget).get("username"));
        }

        ResultSet resultSet = statement.executeQuery();
        if (!resultSet.next()) {
            resultSet.close();
            statement.close();
            connection.close();
            throw new NotFoundException();
        }
        resultSet.close();
        statement.close();
    }

    public static void tryValidateSession(String username, String sessionId, Connection connection)
            throws SQLException, IllegalAccessException, SessionOwnershipException {

        verifySessionIdOwnership(username, sessionId, connection);

        BigDecimal lastActivity = tryGetLastActivity(sessionId, connection);

        if (lastActivity == null) {
            connection.close();
            throw new IllegalAccessException();
        }

        Instant instantNow = Instant.now();
        Instant instantOfLastActivity = Instant.ofEpochSecond(lastActivity.longValue());

        if ((instantOfLastActivity.plus(15, ChronoUnit.MINUTES)).isBefore(instantNow)) {
            deleteFromSessionsTable(sessionId, connection);
            updateAtUsersTable(sessionId, connection);
            connection.close();
            throw new IllegalAccessException();
        }
        else {
            String query = "UPDATE sessions SET last_activity = ? WHERE session_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setBigDecimal(1, new BigDecimal(instantNow.getEpochSecond()));
            statement.setString(2, sessionId);
            statement.executeUpdate();
            statement.close();
        }
    }

    private static BigDecimal tryGetLastActivity(String sessionId, Connection connection)
            throws SQLException {
        String query = "SELECT last_activity FROM sessions WHERE session_id = ? LIMIT 1";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, sessionId);
        ResultSet resultSet = statement.executeQuery();
        if (!resultSet.next()) {
            resultSet.close();
            statement.close();
            return null;
        }
        BigDecimal lastActivity =  resultSet.getBigDecimal("last_activity");
        resultSet.close();
        statement.close();
        return lastActivity;
    }

    private static void verifySessionIdOwnership(String username, String sessionId, Connection connection)
        throws SQLException, SessionOwnershipException {
        String query = "SELECT session_id FROM users WHERE username = ? AND session_id = ? LIMIT 1";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        statement.setString(2, sessionId);
        ResultSet resultSet = statement.executeQuery();
        if (!resultSet.next()) {
            resultSet.close();
            statement.close();
            connection.close();
            throw new SessionOwnershipException();
        }
        resultSet.close();
        statement.close();
    }

    public static void tryValidateUser(String username, Connection connection)
            throws NotFoundException, SQLException {
        existsQuery("username", username, connection);
    }

    public static void tryValidateCatalog(String catalogId, Connection connection)
            throws NotFoundException, SQLException {
        existsQuery("catalog", new BigDecimal(catalogId), connection);
    }

    public static void tryValidateCatalog(BigDecimal catalogId, Connection connection)
            throws NotFoundException, SQLException {
        existsQuery("catalog", catalogId, connection);
    }

    public static void tryValidateMembership(String catalogId, String username, Connection connection)
            throws NotFoundException, SQLException {
        HashMap<String, String> membershipData = new HashMap<>();
        membershipData.put("catalogId", catalogId);
        membershipData.put("username", username);
        existsQuery("membership", membershipData, connection);
    }

    public static void deleteFromSessionsTable(String sessionId, Connection connection) throws SQLException {
        String query = "DELETE FROM sessions WHERE session_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, sessionId);
        statement.executeUpdate();
        statement.close();
    }

    public static void updateAtUsersTable(String cookieValue, Connection connection) throws SQLException {
        String query = "UPDATE users SET session_id = ? WHERE session_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setNull(1, Types.VARCHAR);
        statement.setString(2, cookieValue);
        statement.executeUpdate();
        statement.close();
    }
}
