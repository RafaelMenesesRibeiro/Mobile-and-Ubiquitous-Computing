package com.p2p.helpers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.logging.*;
import org.apache.commons.io.input.ReversedLinesFileReader;

public class P2PhotoServerLogger {
    private static final String SERVER_LOG_FILE_DIR = "logs/";
    private static final String SERVER_LOG = "server_log.log";

    public static Logger setup() {
        // get the global logger so we can configure it
        Logger logger = Logger.getLogger(P2PhotoServerLogger.class.getName());
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.INFO);

        // Configure a volatile memory Handler to log most recent messages
        /*
        FileHandler fileHandler = new FileHandler(SERVER_LOG_FILE_DIR + SERVER_LOG);
        FileHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(fileHandler);
        */
        return logger;
    }

    private String getDateNowFormat() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date dateNow = new Date(System.currentTimeMillis());
        return dateFormat.format(dateNow);
    }

    private static File getLogFileFromResources() {
        ClassLoader classLoader = P2PhotoServerLogger.class.getClassLoader();
        return new File(Objects.requireNonNull(classLoader.getResource(SERVER_LOG)).getFile());
    }

    private static byte[] getFileBytes(File file) throws IOException {
        return Files.readAllBytes(file.toPath());
    }

    public static String getLogFileContents() throws IOException {
        return new String(getFileBytes(getLogFileFromResources()), StandardCharsets.UTF_8);
    }

    public static String getLogFileContentsReverse() throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        ReversedLinesFileReader fileReader = new ReversedLinesFileReader(getLogFileFromResources(), StandardCharsets.UTF_8);
        String contentLine = fileReader.readLine();
        while (contentLine != null) {
            String headingLine = fileReader.readLine();
            stringBuilder.append(headingLine);
            stringBuilder.append(contentLine);
            contentLine = fileReader.readLine();
        }
        fileReader.close();
        return stringBuilder.toString();
    }
}
