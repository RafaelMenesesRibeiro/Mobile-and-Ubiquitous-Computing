package com.p2p.helpers;

import com.p2p.server.msgtypes.BasicResponse;
import com.p2p.server.msgtypes.ErrorResponse;
import com.p2p.server.msgtypes.SuccessResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.logging.Level;

public class ControllerCommons {
    public static final long MAX_CATALOG_ID = 1999999999;

    public static final String BAD_SESSION = "invalid sessionId - cookie does not represent a p2photo sessionId";
    public static final String BAD_OWNERSHIP = "invalid sessionId - does not seem to belong to this user, please login again";
    public static final String OLD_SESSION = "invalid sessionId - old session";

    public static final String OLD_TIMESTAMP = "Invalid timestamp, too old.";

    public static final String BAD_PASS = "invalid password - p2photo passwords must be 8 to 50 characters long";
    public static final String BAD_CREDENTIALS = "invalid password - wrong credentials";

    public static final String BAD_SEARCH = "invalid pattern - can't find users using empty search pattern";
    public static final String BAD_USER = "invalid username - p2photo only accepts non empty strings composed by " +
            "alphanumeric characters, white spaces, no longer than 50 characters";
    public static final String NO_USER = "invalid username - does not exist in p2photo databases";
    public static final String USER_EXISTS = "invalid username - user already exists";

    public static final String NO_MEMBERSHIP = "invalid membership - user does not belong to referenced catalog";

    public static final String BAD_TITLE ="invalid catalogTitle - p2photo only accepts non empty strings composed by " +
            "alphanumeric characters, white spaces, no longer than 50 characters";

    public static final String BAD_SLICE = "invalid slice - not a google drive web content link";
    public static final String BAD_DRIVE_ID = "invalid id - not a google file identifier";

    public static final String BAD_CATALOG = "invalid catalogId - expect string representing a number with 1 to 10 digits";
    public static final String NO_CATALOG = "invalid catalogId - does not exist in p2photo databases";

    public static final String BAD_URI = "no service - server could not connect to databases, try again later.";

    public static final String BAD_KEY = "invalid public key";

    public static ResponseEntity<BasicResponse> newErrorResponse(int code, String message, String operation, String reason) {
        LoggerManager.getInstance().log(Level.WARNING, "/" + operation + "error: " + message + ", reason: " + reason);
        ErrorResponse response = new ErrorResponse(code, message, operation, reason);
        return new ResponseEntity<>(response, HttpStatus.valueOf(code));
    }

    public static ResponseEntity<BasicResponse> newSuccessResponse(int code, String message, String operation, Object result) {
        LoggerManager.getInstance().log(Level.INFO, "/" + operation + "success");
        SuccessResponse response = new SuccessResponse(code, message, operation, result);
        return new ResponseEntity<>(response, HttpStatus.valueOf(code));
    }

    public static ResponseEntity<BasicResponse> newBasicResponse(int code, String message, String operation) {
        LoggerManager.getInstance().log(Level.INFO, "/" + operation + "success");
        BasicResponse response = new BasicResponse(code, message, operation);
        return new ResponseEntity<>(response, HttpStatus.valueOf(code));
    }

    public static ResponseEntity<BasicResponse> newSQLExceptionError(String operation, String message) {
        LoggerManager.getInstance().log(Level.SEVERE, "/" + operation + "with message: " + message);
        ErrorResponse response = new ErrorResponse(500, "internal server error", operation, message);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public static ResponseEntity<BasicResponse> newURISyntaxErrorResponse(String operation) {
        LoggerManager.getInstance().log(Level.SEVERE, "/" + operation + "unreachable database");
        ErrorResponse response = new ErrorResponse(503, "service unavailable", operation, "unreachable database");
        return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
    }
}
