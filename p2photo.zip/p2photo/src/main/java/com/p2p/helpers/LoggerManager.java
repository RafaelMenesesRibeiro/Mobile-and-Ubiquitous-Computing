package com.p2p.helpers;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.logging.*;

public class LoggerManager {
    private static LoggerManager INSTANCE = null;

    private final Logger logger;
    private final ByteArrayOutputStream byteArrayOutputStream;
    private final StreamHandler streamHandler;

    public static LoggerManager getInstance()
    {
        if (INSTANCE == null) {
            INSTANCE = new LoggerManager();
        }
        return INSTANCE;
    }

    private LoggerManager() {
        this.logger = P2PhotoServerLogger.setup();
        // Simple text log messages
        this.byteArrayOutputStream = new ByteArrayOutputStream();
        // Handler that will receive contents from memory handle and transform them into a String
        this.streamHandler = new StreamHandler(this.byteArrayOutputStream, new SimpleFormatter());
        logger.addHandler(streamHandler);
    }

    public void log(Level level, String message) {
        this.streamHandler.publish(new LogRecord(level, message));
        this.streamHandler.flush();
    }

    public String getLogContents() {
        return new String(this.byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);
    }
}
