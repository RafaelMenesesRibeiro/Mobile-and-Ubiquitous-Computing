package com.p2p.helpers;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputProcessor {

    private static final int TOLERANCE = 5;
    private static final int FUTURE_TOLERANCE = 10;
    private static final SimpleDateFormat DATE_FORMAT;

    static {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        DATE_FORMAT = dateFormat;
    }

    public static boolean isValidAlphanumericString(String str) {
        return str != null && !str.equals("") && isAlphanumericString(str, false) && str.length() <= 50;
    }

    public static boolean isValidAlphanumericWithSpacesString(String str) {
        return str != null && !str.equals("") && isAlphanumericString(str, true) && str.length() <= 50;
    }

    public static boolean isValidString(String str) {
        return str != null && !str.equals("") && str.length() <= 64;
    }

    public static boolean isValidSliceURL(String str) {
        try {
            new URL(str);
            return true;
        } catch (MalformedURLException exc) {
            return false;
        }
    }

    public static boolean isValidPassword(String str) {
        return str != null && !str.equals("") && str.length() >= 8 && str.length() <= 50;
    }

    public static boolean isValidBigDecimal(String str) {
        if (!isValidAlphanumericString(str) || str.length() > 10) {
            return false;
        }
        try {
            new BigDecimal(str);
            return true;
        } catch (NumberFormatException exc) {
            return false;
        }
    }

    public static boolean isValidUUID(String str) {
        try {
            UUID.fromString(str);
            return true;
        } catch (IllegalArgumentException exc) {
            return false;
        }
    }

    public static boolean isAlphanumericString(String catalogTitle, boolean bool) {
        Pattern pattern;

        if (bool) {
            pattern = Pattern.compile("^[ a-zA-Z0-9]+$");
        } else {
            pattern = Pattern.compile("^[a-zA-Z0-9]+$");
        }

        Matcher matcher = pattern.matcher(catalogTitle);
        return matcher.matches();
    }

    public static boolean isFreshTimestamp(String rcvTimestamp) {
        // TODO - Solve heroku being an hour earlier. //
        return true;
        /*
        try {
            Calendar calendar = Calendar.getInstance();
            Date dateNow = new Date();
            calendar.setTime(new Date());
            calendar.add(Calendar.MINUTE, 1);
            Date dateRcv = DATE_FORMAT.parse(rcvTimestamp);
            return dateRcv.before(dateNow) && dateRcv.after(calendar.getTime());
        } catch (Exception e) {
            return false;
        }
        */
    }
}
