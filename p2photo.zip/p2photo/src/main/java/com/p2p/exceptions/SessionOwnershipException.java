package com.p2p.exceptions;

public class SessionOwnershipException extends Exception {
}
