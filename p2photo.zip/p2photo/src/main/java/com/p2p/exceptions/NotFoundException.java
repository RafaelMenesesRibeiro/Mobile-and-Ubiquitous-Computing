package com.p2p.exceptions;

public class NotFoundException extends Exception {
}
