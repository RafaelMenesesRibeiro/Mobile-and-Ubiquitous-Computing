package com.p2p.server.controllers;

import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.isValidAlphanumericString;
import static com.p2p.helpers.InputProcessor.isValidUUID;

@SuppressWarnings("Duplicates")
@RestController
public class LogoutController {
    private static final String OPERATION = "logout";

    @DeleteMapping(value = "/logout/{calleeUsername}")
    public ResponseEntity<BasicResponse> logoutHandle(@PathVariable(value = "calleeUsername") String calleeUsername,
                                                      @CookieValue(value = "sessionId") String sessionIdCookie) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"DELETE request at /logout controller");

        if (!isValidUUID(sessionIdCookie)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }

        if (!isValidAlphanumericString(calleeUsername)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }

        try {
            UUID.fromString(sessionIdCookie);
            Connection connection = getJDBCConnection();

            try {
                tryValidateSession(calleeUsername, sessionIdCookie, connection);
            } catch (IllegalAccessException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
            } catch (SessionOwnershipException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
            }

            deleteFromSessionsTable(sessionIdCookie, connection);
            updateAtUsersTable(sessionIdCookie, connection);

            connection.close();
            return newBasicResponse(200, "ok", OPERATION);
        } catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        } catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

}