package com.p2p.server.controllers;

import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class ViewCatalogController {
    private static final String OPERATION = "viewCatalog";

    @GetMapping(value = "/viewCatalog", params = { "catalogId", "calleeUsername" })
    public ResponseEntity<BasicResponse> viewCatalogHandle(@RequestParam("catalogId") String catalogId,
                                                           @RequestParam("calleeUsername") String calleeUsername,
                                                           @CookieValue(value = "sessionId") String sessionIdCookie) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /viewCatalog controller");

        if (!isValidUUID(sessionIdCookie)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidAlphanumericString(calleeUsername)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }
        if (!isValidBigDecimal(catalogId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
        }

        try {
            Connection connection = getJDBCConnection();
            try {
                tryValidateSession(calleeUsername, sessionIdCookie, connection);
            } catch (IllegalAccessException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
            } catch (SessionOwnershipException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
            }

            try {
                tryValidateCatalog(catalogId, connection);
            } catch (NotFoundException exc) {
                return newErrorResponse(404, "not found", OPERATION, NO_CATALOG);
            }

            ArrayList<String> googleCatalogFileSlices = viewCatalog(catalogId, connection);

            connection.close();
            return newSuccessResponse(200, "ok", OPERATION, googleCatalogFileSlices);
        } catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        } catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private ArrayList<String> viewCatalog(String catalogId, Connection connection) throws SQLException {
        String query = "SELECT slices FROM catalogs WHERE catalog_id = ?";
        String slicesText = "";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setBigDecimal(1, new BigDecimal(catalogId));
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            slicesText = resultSet.getString("slices");
        }

        ArrayList<String> googleCatalogFileSlices =
                new ArrayList<>(Arrays.asList(slicesText.split("(\\r\\n|\\r|\\n)")));

        googleCatalogFileSlices.removeAll(Arrays.asList(null,""));

        resultSet.close();
        statement.close();

        return googleCatalogFileSlices;
    }
}
