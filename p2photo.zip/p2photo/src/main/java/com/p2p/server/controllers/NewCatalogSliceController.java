package com.p2p.server.controllers;

import com.p2p.domain.NewCatalogSliceData;
import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;

import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;
import static com.p2p.helpers.ControllerCommons.*;

@SuppressWarnings("Duplicates")
@RestController
public class NewCatalogSliceController {
    private static final String OPERATION = "newCatalogSlice";

    @PutMapping(value = "/newCatalogSlice/{catalogId}")
    public ResponseEntity<BasicResponse> newCatalogSliceHandle(@PathVariable String catalogId,
                                                               @RequestBody NewCatalogSliceData requestData,
                                                               @CookieValue(value = "sessionId") String sessionIdCookie) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"PUT request at /newCatalogSlice/" + catalogId + " controller");

        String parentFolderGoogleId = requestData.getParentFolderGoogleId();
        String catalogFileGoogleId = requestData.getCatalogFileGoogleId();
        String webContentLink = requestData.getWebContentLink();
        String calleeUsername = requestData.getCalleeUsername();

        if(!isFreshTimestamp(requestData.getTimestamp())) {
            return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
        }
        if (!isValidUUID(sessionIdCookie)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidBigDecimal(catalogId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
        }
        if (!isValidAlphanumericString(calleeUsername)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }
        if (!isValidString(parentFolderGoogleId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_DRIVE_ID);
        }
        if (!isValidString(catalogFileGoogleId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_DRIVE_ID);
        }
        if (!isValidSliceURL(webContentLink)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SLICE);
        }

        try (Connection connection = getJDBCConnection()) {
            tryValidateSession(calleeUsername, sessionIdCookie, connection);
            tryValidateMembership(catalogId, requestData.getCalleeUsername(), connection);

            updateCatalogsTableWithGoogleCatalogId(catalogId, requestData, connection);
            updateMembershipsTableWithGoogleCatalogId(catalogId, requestData, connection);
            return newBasicResponse(200, "ok", OPERATION);
        }
        catch (IllegalAccessException exc) {
            return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
        }
        catch (SessionOwnershipException exc) {
            return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
        }
        catch (NotFoundException exc) {
            return newErrorResponse(403, "forbidden", OPERATION, NO_MEMBERSHIP);
        }
        catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        }
        catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private void updateCatalogsTableWithGoogleCatalogId(String catalogIdString,
                                                        NewCatalogSliceData newCatalogSliceData,
                                                        Connection connection) throws SQLException {

        BigDecimal catalogId = new BigDecimal(catalogIdString);
        String webContentLink = newCatalogSliceData.getWebContentLink();
        String query = "UPDATE catalogs SET slices = slices || ? WHERE catalog_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1,webContentLink + "\n");
        statement.setBigDecimal(2, catalogId);
        statement.executeUpdate();
        statement.close();
    }

    private void updateMembershipsTableWithGoogleCatalogId(String catalogIdString,
                                                           NewCatalogSliceData newCatalogSliceData,
                                                           Connection connection) throws SQLException {

        String query = "UPDATE memberships" +
                " SET parent_folder_drive_id = ?, catalog_drive_id = ? " +
                " WHERE catalog_id = ? AND username = ?";

        BigDecimal catalogId = new BigDecimal(catalogIdString);
        String parentFolderGoogleId = newCatalogSliceData.getParentFolderGoogleId();
        String catalogFileGoogleId = newCatalogSliceData.getCatalogFileGoogleId();
        String calleeUsername = newCatalogSliceData.getCalleeUsername();

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, parentFolderGoogleId);
        statement.setString(2, catalogFileGoogleId);
        statement.setBigDecimal(3, catalogId);
        statement.setString(4, calleeUsername);
        statement.executeUpdate();
        statement.close();

    }
}
