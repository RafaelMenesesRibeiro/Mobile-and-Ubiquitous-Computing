package com.p2p.server.controllers;

import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.p2p.helpers.ControllerCommons.newBasicResponse;

@RestController
public class ViewLogsController {
    private static final String OPERATION = "viewLogs";

    @GetMapping(value = "/viewLogs")
    public ResponseEntity<BasicResponse> viewCatalogDetailsHandle() {
        return newBasicResponse(200, LoggerManager.getInstance().getLogContents(), OPERATION);
    }
}
