package com.p2p.server.controllers;

import com.p2p.domain.NewKeyData;
import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class NewMemberKeyController {
	private static final String OPERATION = "newMemberKey";

	@PostMapping(value = "/newMemberKey")
	public ResponseEntity<BasicResponse> newCatalogHandle(@RequestBody NewKeyData requestData,
														  @CookieValue(value = "sessionId") String sessionIdCookie) {

		LoggerManager logger = LoggerManager.getInstance();
		logger.log(Level.INFO,"POST request at /newMemberKey controller");

		String calleeUsername = requestData.getCalleeUsername();
		String publicKey = requestData.getPublicKey();

		if(!isFreshTimestamp(requestData.getTimestamp())) {
			return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
		}
		if (!isValidUUID(sessionIdCookie)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
		}
		if (!isValidAlphanumericString(calleeUsername)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
		}
		if (publicKey == null) {
			return newErrorResponse(400, "Public Key cannot be null", OPERATION, BAD_KEY);
		}

		try (Connection connection = getJDBCConnection()) {
			tryValidateUser(calleeUsername, connection);
			tryValidateSession(calleeUsername, sessionIdCookie, connection);
			updateUsersTable(connection, calleeUsername, publicKey);
			return newBasicResponse(200, "ok", OPERATION);
		}
		catch (IllegalAccessException exc) {
			return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
		}
		catch (SessionOwnershipException exc) {
			return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
		}
		catch (NotFoundException exc) {
			return newErrorResponse(404, "not found", OPERATION, NO_USER);
		}
		catch (URISyntaxException urise) {
			return newURISyntaxErrorResponse(OPERATION);
		}
		catch (SQLException sqle) {
			return newSQLExceptionError(OPERATION, sqle.getMessage());
		}
	}

	private void updateUsersTable(Connection connection, String username, String publicKey) throws SQLException {
		String query = "UPDATE users SET public_key = ? WHERE username = ?";

		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, publicKey);
		statement.setString(2, username);
		statement.executeUpdate();
		statement.close();
	}
}

