package com.p2p.server.controllers;

import com.p2p.domain.CredentialsData;
import com.p2p.helpers.DatabaseManager;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class SignupController {
    private static final String OPERATION = "signup";

    @PostMapping(value = "/signup")
    public ResponseEntity<BasicResponse> signupHandle(@RequestBody CredentialsData requestData) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /signup controller");

        String username = requestData.getUsername();
        String publicKey = requestData.getPublicKey();

        if(!isFreshTimestamp(requestData.getTimestamp())) {
            return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
        }
        if (!isValidAlphanumericString(username)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }
        if (!isValidPassword(requestData.getPassword())) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_PASS);
        }
        if (publicKey == null) {
            return newErrorResponse(400, "Public Key cannot be null", OPERATION, BAD_KEY);
        }
        if (isUserExists(username)) {
            return newErrorResponse(409, "bad user", OPERATION, USER_EXISTS);
        }

        try {
            signup(requestData);
            return newBasicResponse(200, "ok", OPERATION);
        }
        catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        }
        catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private boolean isUserExists(String username) {
        try {
            String query = "select * from users where username = ?";
            Connection connection = DatabaseManager.getJDBCConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                resultSet.close();
                statement.close();
                connection.close();
                return false;
            }
            resultSet.close();
            statement.close();
            connection.close();
            return true;
        }
        catch (Exception e) {
            return true;
        }
    }

    private void signup(CredentialsData credentialsData) throws SQLException, URISyntaxException {
        String query = "INSERT INTO users (username,password_hash,session_id,public_key) VALUES (?,crypt(?,gen_salt('bf', 8)),?,?)";
        Connection connection = DatabaseManager.getJDBCConnection();
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, credentialsData.getUsername().toLowerCase());
        statement.setString(2, credentialsData.getPassword());
        statement.setString(3, null);
        statement.setString(4, credentialsData.getPublicKey());
        statement.executeUpdate();
        statement.close();
        connection.close();
    }
}
