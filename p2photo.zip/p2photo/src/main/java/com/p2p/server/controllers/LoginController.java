package com.p2p.server.controllers;

import com.p2p.domain.CredentialsData;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.security.auth.login.FailedLoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class LoginController {
    private static final String OPERATION = "login";

    @PostMapping(value = "/login")
    public ResponseEntity<BasicResponse> loginHandle(@RequestBody CredentialsData requestData,
                                                     HttpServletRequest request,
                                                     HttpServletResponse response) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /login controller");

        String username = requestData.getUsername();
        String password = requestData.getPassword();

        if(!isFreshTimestamp(requestData.getTimestamp())) {
            return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
        }
        if (!isValidAlphanumericString(username)) {
            return newErrorResponse(400, "bad request - username found - " + username, OPERATION, BAD_USER);
        }
        if (!isValidPassword(password)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_PASS);
        }

        try (Connection connection = getJDBCConnection()) {
            String cookieValue = UUID.randomUUID().toString();
            verifyCredentials(username, password, connection);
            tryClearOldSessions(username, connection);
            tryCreateNewSession(username, cookieValue, request, connection);
            response.addHeader("Set-Cookie", "" + cookieValue);
            return newSuccessResponse(200, "ok", OPERATION, cookieValue);
        }
        catch (FailedLoginException exc) {
            logger.log(Level.WARNING, "/login error due to wrong credentials");
            return newErrorResponse(401, "unauthorized", OPERATION, BAD_CREDENTIALS);
        }
        catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        }
        catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private void verifyCredentials(String username, String password_hypothesis, Connection connection) throws SQLException, FailedLoginException {
        String query = "SELECT user FROM users WHERE username = lower(?) AND password_hash = crypt(?,password_hash)";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        statement.setString(2, password_hypothesis);
        ResultSet resultSet = statement.executeQuery();
        if (!resultSet.next()) {
            resultSet.close();
            statement.close();
            connection.close();
            throw new FailedLoginException();
        }
        resultSet.close();
        statement.close();
    }

    private void tryClearOldSessions(String username, Connection connection) throws SQLException {
        String query = "SELECT session_id FROM users WHERE username = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet resultSet = statement.executeQuery();

        if (!resultSet.next()) {
            resultSet.close();
            statement.close();
        }
        else {
            String oldSessionId = resultSet.getString("session_id");
            resultSet.close();
            statement.close();
            deleteFromSessionsTable(oldSessionId, connection);
            updateAtUsersTable(oldSessionId, connection);
        }
    }


    private void tryCreateNewSession(String username, String cookieValue, HttpServletRequest request, Connection connection) throws SQLException {
        updateUsersTable(username, cookieValue, connection);
        updateSessionsTable(cookieValue, request, connection);
    }

    private void updateUsersTable(String username, String cookieValue, Connection connection) throws  SQLException {
        String query = "UPDATE users SET session_id = ? WHERE username = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, cookieValue);
        statement.setString(2, username);
        statement.executeUpdate();
        statement.close();
    }

    private void updateSessionsTable(String cookieValue, HttpServletRequest request, Connection connection) throws  SQLException {
        String ipAddress = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");
        String userData = null;
        BigDecimal lastActivity = getEpochSecondNow();

        String query = "INSERT INTO sessions (session_id,ip,user_agent,user_data,last_activity) VALUES (?,?,?,?,?)";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, cookieValue);
        statement.setString(2, ipAddress);
        statement.setString(3, userAgent);
        statement.setString(4, userData);
        statement.setBigDecimal(5, lastActivity);
        statement.executeUpdate();
        statement.close();
    }
}
