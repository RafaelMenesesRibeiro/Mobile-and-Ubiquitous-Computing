package com.p2p.server.controllers;

import com.p2p.domain.NewCatalogMemberData;
import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.logging.Level;

import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;
import static com.p2p.helpers.ControllerCommons.*;

@SuppressWarnings("Duplicates")
@RestController
public class NewCatalogMemberController {
    private static final String OPERATION = "newCatalogMember";

    @PostMapping(value = "/newCatalogMember")
    public ResponseEntity<BasicResponse> newCatalogMemberHandle(@RequestBody NewCatalogMemberData requestData,
                                                                @CookieValue(value = "sessionId") String sessionIdCookie) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /newCatalogMember controller");

        String catalogId = requestData.getCatalogId();
        String newMemberUsername = requestData.getNewMemberUsername();
        String calleeUsername = requestData.getCalleeUsername();

        if(!isFreshTimestamp(requestData.getTimestamp())) {
            return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
        }
        if (!isValidUUID(sessionIdCookie)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidBigDecimal(catalogId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
        }
        if (!isValidAlphanumericString(calleeUsername) || !isValidAlphanumericString(newMemberUsername)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }

        try (Connection connection = getJDBCConnection()) {
            try {
                tryValidateSession(calleeUsername, sessionIdCookie, connection);
            }
            catch (IllegalAccessException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
            }
            catch (SessionOwnershipException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
            }

            try {
                tryValidateCatalog(catalogId, connection);
            }
            catch (NotFoundException exc) {
                return newErrorResponse(404, "not found", OPERATION, NO_CATALOG);
            }

            try {
                tryValidateMembership(catalogId, calleeUsername, connection);
            } catch (NotFoundException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, NO_MEMBERSHIP);
            }

            try {
                tryValidateUser(newMemberUsername, connection);
            }
            catch (NotFoundException exc) {
                return newErrorResponse(404, "not found", OPERATION, NO_USER);
            }

            try {
                newCatalogMember(catalogId, newMemberUsername, connection);
            }
            catch (SQLIntegrityConstraintViolationException | DataIntegrityViolationException exc) {
                return newBasicResponse(200, "ok", OPERATION);
            }

            return newBasicResponse(200, "ok", OPERATION);
        }
        catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        }
        catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private void newCatalogMember(String catalogId, String username, Connection connection) throws SQLException {
        String query = "INSERT INTO memberships (catalog_id, username) SELECT ?, ? " +
                        "WHERE " +
                            "NOT EXISTS ( " +
                            "SELECT * FROM memberships WHERE catalog_id=? and username=?);";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setBigDecimal(1, new BigDecimal(catalogId));
        statement.setString(2, username);
        statement.setBigDecimal(3, new BigDecimal(catalogId));
        statement.setString(4, username);
        statement.executeUpdate();
        statement.close();
    }
}
