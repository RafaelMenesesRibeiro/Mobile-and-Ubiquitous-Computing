package com.p2p.server.controllers;

import com.p2p.domain.NewCatalogData;
import com.p2p.exceptions.NotFoundException;
import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.*;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class NewCatalogController {
    private static final String OPERATION = "newCatalog";

    @PostMapping(value = "/newCatalog")
    public ResponseEntity<BasicResponse> newCatalogHandle(@RequestBody NewCatalogData requestData,
                                                          @CookieValue(value = "sessionId") String sessionIdCookie) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /newCatalog controller");

        String catalogTitle = requestData.getCatalogTitle();
        String calleeUsername = requestData.getCalleeUsername();

        if(!isFreshTimestamp(requestData.getTimestamp())) {
            return newErrorResponse(408, "Timestamp " + requestData.getTimestamp() + " is too old", OPERATION, OLD_TIMESTAMP);
        }
        if (!isValidUUID(sessionIdCookie)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidAlphanumericWithSpacesString(catalogTitle)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
        }
        if (!isValidAlphanumericString(calleeUsername)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }

        try (Connection connection = getJDBCConnection()) {
            tryValidateSession(calleeUsername, sessionIdCookie, connection);
            tryValidateUser(calleeUsername, connection);
            BigDecimal catalogID = tryGenerateValidCatalogId();

            updateCatalogsTable(catalogID, catalogTitle, connection);
            updateMembershipsTable(catalogID, calleeUsername, connection);
            return newSuccessResponse(200, "ok", OPERATION, catalogID.toPlainString());
        }
        catch (IllegalAccessException exc) {
            return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
        }
        catch (SessionOwnershipException exc) {
            return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
        }
        catch (NotFoundException exc) {
            return newErrorResponse(404, "not found", OPERATION, NO_USER);
        }
        catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        }
        catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private void updateCatalogsTable(BigDecimal catalogID, String catalogTitle, Connection connection) throws SQLException {
        String query = "INSERT INTO catalogs (catalog_id,catalog_title,slices) SELECT ?, ?, ? " +
                "WHERE " +
                "NOT EXISTS ( " +
                "SELECT * FROM catalogs WHERE catalog_id=?);";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setBigDecimal(1, catalogID);
        statement.setString(2, catalogTitle);
        statement.setString(3, "");
        statement.setBigDecimal(4, catalogID);
        statement.executeUpdate();
        statement.close();
    }

    private void updateMembershipsTable(BigDecimal catalogID, String calleeUsername, Connection connection) throws SQLException {
        String query = "INSERT INTO memberships (catalog_id,username) SELECT ?, ? " +
                "WHERE " +
                "NOT EXISTS ( " +
                "SELECT * FROM memberships WHERE catalog_id=? and username=?);";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setBigDecimal(1, catalogID);
        statement.setString(2, calleeUsername);
        statement.setBigDecimal(3, catalogID);
        statement.setString(4, calleeUsername);
        statement.executeUpdate();
        statement.close();
    }

    private BigDecimal tryGenerateValidCatalogId() throws SQLException, URISyntaxException {
        Connection connection = getJDBCConnection();
        while (true) {
            BigDecimal catalogId = generateNewBigDecimalId();
            try {
                tryValidateCatalog(catalogId, connection);
            }
            catch (NotFoundException exc) {
                return catalogId;
            }
        }
    }

    private BigDecimal generateNewBigDecimalId() {
        SecureRandom randomGenerator = new SecureRandom();
        long randomValue = Math.abs(randomGenerator.nextLong());
        while (randomValue > MAX_CATALOG_ID) {
            randomValue = randomValue / 10;
        }
        return new BigDecimal(randomValue);
    }
}
