package com.p2p.server.controllers;

import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.getJDBCConnection;
import static com.p2p.helpers.DatabaseManager.tryValidateSession;
import static com.p2p.helpers.InputProcessor.isValidAlphanumericString;
import static com.p2p.helpers.InputProcessor.isValidUUID;

@SuppressWarnings("Duplicates")
@RestController
public class GetMembershipsController {
	private static final String OPERATION = "getMemberships";

	@GetMapping(value = "/getMemberships")
	public ResponseEntity<BasicResponse> getMembershipsHandle(@RequestParam("calleeUsername") String calleeUsername,
															  @CookieValue(value = "sessionId") String sessionIdCookie) {

		LoggerManager logger = LoggerManager.getInstance();
		logger.log(Level.INFO,"GET request at /getMemberships controller");

		if (!isValidUUID(sessionIdCookie)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
		}
		if (!isValidAlphanumericString(calleeUsername)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
		}

		try {
			Connection connection = getJDBCConnection();
			try {
				tryValidateSession(calleeUsername, sessionIdCookie, connection);
			} catch (IllegalAccessException exc) {
				return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
			} catch (SessionOwnershipException exc) {
				return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
			}

			HashMap<String, String> memberships = getMemberships(calleeUsername ,connection);
			connection.close();
			return newSuccessResponse(200, "ok", OPERATION, memberships);
		} catch (URISyntaxException urise) {
			return newURISyntaxErrorResponse(OPERATION);
		} catch (SQLException sqle) {
			return newSQLExceptionError(OPERATION, sqle.getMessage());
		}
	}

	private HashMap<String, String> getMemberships(String username, Connection connection) throws SQLException {
		String query = "select catalogs.catalog_id, catalog_title" +
						" from catalogs" +
						" inner join memberships" +
						" on catalogs.catalog_id = memberships.catalog_id" +
						" where username = ?;";

		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, username);
		ResultSet resultSet = statement.executeQuery();

		HashMap<String, String> memberships = new HashMap<>();
		while (resultSet.next()) {
			String p2pCatalogId = resultSet.getBigDecimal(1).toPlainString();
			String googleCatalogId = resultSet.getString(2);

			if (googleCatalogId == null) {
				googleCatalogId = "";
			}

			memberships.put(p2pCatalogId, googleCatalogId);
		}

		resultSet.close();
		statement.close();

		return memberships;
	}
}


