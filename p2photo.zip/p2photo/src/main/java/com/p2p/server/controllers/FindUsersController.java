package com.p2p.server.controllers;

import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.getJDBCConnection;
import static com.p2p.helpers.DatabaseManager.tryValidateSession;
import static com.p2p.helpers.InputProcessor.isValidAlphanumericString;
import static com.p2p.helpers.InputProcessor.isValidUUID;

@SuppressWarnings("Duplicates")
@RestController
public class FindUsersController {
    private static final String OPERATION = "findUsers";

    @GetMapping(value = "/findUsers", params = { "searchPattern", "bringCatalogs", "calleeUsername" })
    public ResponseEntity<BasicResponse> findUsersHandle(@RequestParam("searchPattern") String searchPattern,
                                                         @RequestParam("bringCatalogs") String bringCatalogs,
                                                         @RequestParam("calleeUsername") String calleeUsername,
                                                         @CookieValue(value = "sessionId") String sessionId) {

        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"GET request at /findUsers controller");

        if (!isValidUUID(sessionId)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidAlphanumericString(searchPattern)) {
            return newErrorResponse(400, "bad request", OPERATION, BAD_SEARCH);
        }

        try {
            Connection connection = getJDBCConnection();
            try {
                tryValidateSession(calleeUsername, sessionId, connection);
            } catch (IllegalAccessException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
            } catch (SessionOwnershipException exc) {
                return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
            }

            ArrayList<String> foundUsersList = findUsers(searchPattern, connection);
            if (foundUsersList.isEmpty() || bringCatalogs.equals("false")) {
                return newSuccessResponse(200, "ok", OPERATION, foundUsersList);
            }

            HashMap<String, ArrayList<String>> usersCatalogsMap = findUsersCatalogs(foundUsersList, connection);
            connection.close();

            return newSuccessResponse(200, "ok", OPERATION, usersCatalogsMap);
        } catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        } catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private ArrayList<String> findUsers(String usernamePattern, Connection connection) throws SQLException {
        ArrayList<String> foundUsersList = new ArrayList<>();

        String query = "SELECT username FROM users WHERE username LIKE ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, "%" + usernamePattern.trim().toLowerCase() + "%");
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) { foundUsersList.add(resultSet.getString(1)); }

        resultSet.close();
        statement.close();

        return foundUsersList;
    }

    private HashMap<String, ArrayList<String>> findUsersCatalogs(
            ArrayList<String> usersList, Connection connection) throws SQLException {

        HashMap<String, ArrayList<String>> usersMap = new HashMap<>();

        for (String username : usersList) {
            ArrayList<String> userCatalogs = findUserCatalogs(username, connection);
            usersMap.put(username, userCatalogs);
        }

        return usersMap;
    }

    private ArrayList<String> findUserCatalogs(String username, Connection connection) throws SQLException {
        ArrayList<String> userCatalogs = new ArrayList<>();

        String query = "SELECT DISTINCT catalog_id FROM memberships WHERE username = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            BigDecimal catalogId = resultSet.getBigDecimal("catalog_id");
            userCatalogs.add(catalogId.toPlainString());
        }

        resultSet.close();
        statement.close();

        return userCatalogs;
    }
}
