package com.p2p.server.controllers;

import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.getJDBCConnection;
import static com.p2p.helpers.DatabaseManager.tryValidateSession;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class AssertMembershipController {
	private static final String OPERATION = "assertMembership";

	@GetMapping(value = "/assertMembership")
	public ResponseEntity<BasicResponse> assertMembershipHandler(@RequestParam("calleeUsername") String calleeUsername,
															  @RequestParam("toGetUsername") String toGetUsername,
															  @RequestParam("catalogID") String catalogID,
															  @CookieValue(value = "sessionId") String sessionIdCookie) {

		LoggerManager logger = LoggerManager.getInstance();
		logger.log(Level.INFO, "GET request at /assertMembership controller");

		if (!isValidUUID(sessionIdCookie)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
		}
		if (!isValidAlphanumericString(calleeUsername)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
		}
		if (!isValidAlphanumericString(toGetUsername)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
		}
		if (!isValidBigDecimal(catalogID)) {
			return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
		}

		try {
			Connection connection = getJDBCConnection();
			try {
				tryValidateSession(calleeUsername, sessionIdCookie, connection);
			}
			catch (IllegalAccessException exc) {
				return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
			}
			catch (SessionOwnershipException exc) {
				return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
			}

			int isMember = assertMembership(connection, toGetUsername, catalogID);

			connection.close();
			return newSuccessResponse(200, "ok", OPERATION, isMember);
		}
		catch (URISyntaxException urise) {
			return newURISyntaxErrorResponse(OPERATION);
		}
		catch (SQLException sqle) {
			return newSQLExceptionError(OPERATION, sqle.getMessage());
		}
	}

		private int assertMembership(Connection connection, String username, String catalodID) throws SQLException {
			String query = "select username from memberships where catalog_id = ? and username = ?;";

			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, catalodID);
			statement.setString(2, username);
			ResultSet resultSet = statement.executeQuery();

			if (resultSet.next()) {
				String name = resultSet.getString("username");
				resultSet.close();
				statement.close();
				return 1;
			}
			resultSet.close();
			statement.close();
			return 0;
		}
}
