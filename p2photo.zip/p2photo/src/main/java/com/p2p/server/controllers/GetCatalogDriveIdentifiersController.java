package com.p2p.server.controllers;

import com.p2p.exceptions.SessionOwnershipException;
import com.p2p.helpers.ControllerCommons;
import com.p2p.helpers.LoggerManager;
import com.p2p.server.msgtypes.BasicResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;

import static com.p2p.helpers.ControllerCommons.*;
import static com.p2p.helpers.DatabaseManager.getJDBCConnection;
import static com.p2p.helpers.DatabaseManager.tryValidateSession;
import static com.p2p.helpers.InputProcessor.*;

@SuppressWarnings("Duplicates")
@RestController
public class GetCatalogDriveIdentifiersController {
    private static final String OPERATION = "getCatalogDriveIdentifiers";

    @GetMapping(value = "/getCatalogDriveIdentifiers")
    public ResponseEntity<BasicResponse> getCatalogDriveIdentifiersHandle(@RequestParam("catalogId") String catalogId,
                                                                          @RequestParam("calleeUsername") String calleeUsername,
                                                                          @CookieValue(value = "sessionId") String sessionIdCookie) {
        LoggerManager logger = LoggerManager.getInstance();
        logger.log(Level.INFO,"POST request at /getCatalogDriveIdentifiers controller");

        if (!isValidUUID(sessionIdCookie)) {
            logger.log(Level.WARNING, "/getCatalogDriveIdentifiers error in sessionId");
            return newErrorResponse(400, "bad request", OPERATION, BAD_SESSION);
        }
        if (!isValidAlphanumericString(calleeUsername)) {
            logger.log(Level.WARNING, "/getCatalogDriveIdentifiers error in calleeUsername");
            return newErrorResponse(400, "bad request", OPERATION, BAD_USER);
        }
        if (!isValidBigDecimal(catalogId)) {
            logger.log(Level.WARNING, "/getCatalogDriveIdentifiers error in catalogId");
            return newErrorResponse(400, "bad request", OPERATION, BAD_TITLE);
        }

        try {
            Connection connection = getJDBCConnection();
            try {
                tryValidateSession(calleeUsername, sessionIdCookie, connection);
            } catch (IllegalAccessException exc) {
                logger.log(Level.WARNING, "/getCatalogDriveIdentifiers session timed out");
                return newErrorResponse(401, "unauthorized access", OPERATION, OLD_SESSION);
            } catch (SessionOwnershipException exc) {
                logger.log(Level.WARNING, "/getCatalogDriveIdentifiers callee doesn't own sent session");
                return newErrorResponse(401, "unauthorized access", OPERATION, BAD_OWNERSHIP);
            }

            HashMap<String, String> googleIdentifiers = getGoogleIdentifiers(catalogId, calleeUsername, connection);
            connection.close();
            return newSuccessResponse(200, "ok", OPERATION, googleIdentifiers);
        } catch (URISyntaxException urise) {
            return newURISyntaxErrorResponse(OPERATION);
        } catch (SQLException sqle) {
            return newSQLExceptionError(OPERATION, sqle.getMessage());
        }
    }

    private HashMap<String, String> getGoogleIdentifiers(String catalogId,
                                                         String username,
                                                         Connection connection) throws SQLException {

        String query = "SELECT parent_folder_drive_id, catalog_drive_id FROM memberships WHERE catalog_id = ? and  username = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setBigDecimal(1, new BigDecimal(catalogId));
        statement.setString(2, username);
        ResultSet resultSet = statement.executeQuery();

        HashMap<String, String> googleIdentifiers = new HashMap<>();

        while (resultSet.next()) {
            String key = resultSet.getString("parent_folder_drive_id");
            String value = resultSet.getString("catalog_drive_id");
            googleIdentifiers.put(key, value);
        }

        resultSet.close();
        statement.close();

        return googleIdentifiers;
    }
}
