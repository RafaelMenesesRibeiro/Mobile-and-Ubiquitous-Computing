package com.p2p.server.msgtypes;

public class SuccessResponse extends BasicResponse {
    private Object result;

    public SuccessResponse(int code, String message, String operation, Object result) {
        super(code, message, operation);
        this.result = result;
    }

    public SuccessResponse() {}

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
}
