package com.p2p.domain;

public class BasicMessage {
	private String timestamp;
	private String requestID;

	public BasicMessage() {}

	public BasicMessage(String timestamp, String requestID) {
		this.timestamp = timestamp;
		this.requestID = requestID;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
}
