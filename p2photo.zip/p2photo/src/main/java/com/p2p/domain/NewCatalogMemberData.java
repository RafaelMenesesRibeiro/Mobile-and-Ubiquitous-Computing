package com.p2p.domain;

public class NewCatalogMemberData extends BasicMessage {
    private String catalogId;
    private String newMemberUsername;
    private String calleeUsername;

    public NewCatalogMemberData() { }

    public NewCatalogMemberData(String timestamp, String requestID, String catalogId, String newMemberUsername, String calleeUsername) {
        super(timestamp, requestID);
        this.catalogId = catalogId;
        this.newMemberUsername = newMemberUsername;
        this.calleeUsername = calleeUsername;
    }

    public String getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(String catalogId) {
        this.catalogId = catalogId;
    }

    public String getNewMemberUsername() {
        return newMemberUsername;
    }

    public void setNewMemberUsername(String newMemberUsername) {
        this.newMemberUsername = newMemberUsername;
    }

    public String getCalleeUsername() {
        return calleeUsername;
    }

    public void setCalleeUsername(String calleeUsername) {
        this.calleeUsername = calleeUsername;
    }
}
