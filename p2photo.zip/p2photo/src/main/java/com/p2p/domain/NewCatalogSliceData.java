package com.p2p.domain;

public class NewCatalogSliceData extends BasicMessage{
    private String parentFolderGoogleId;
    private String catalogFileGoogleId;
    private String webContentLink;
    private String calleeUsername;

    public NewCatalogSliceData(String timestamp, String requestID, String parentFolderGoogleId, String catalogFileGoogleId, String webContentLink, String calleeUsername) {
        super(timestamp, requestID);
        this.parentFolderGoogleId = parentFolderGoogleId;
        this.catalogFileGoogleId = catalogFileGoogleId;
        this.webContentLink = webContentLink;
        this.calleeUsername = calleeUsername;
    }

    public NewCatalogSliceData() {
    }

    public String getParentFolderGoogleId() {
        return parentFolderGoogleId;
    }

    public void setParentFolderGoogleId(String parentFolderGoogleId) {
        this.parentFolderGoogleId = parentFolderGoogleId;
    }

    public String getCatalogFileGoogleId() {
        return catalogFileGoogleId;
    }

    public void setCatalogFileGoogleId(String catalogFileGoogleId) {
        this.catalogFileGoogleId = catalogFileGoogleId;
    }

    public String getCalleeUsername() {
        return calleeUsername;
    }

    public void setCalleeUsername(String calleeUsername) {
        this.calleeUsername = calleeUsername;
    }

    public String getWebContentLink() {
        return webContentLink;
    }

    public void setWebContentLink(String webContentLink) {
        this.webContentLink = webContentLink;
    }

    @Override
    public String toString() {
        return "NewCatalogSliceData{" +
                "parentFolderGoogleId='" + parentFolderGoogleId + '\'' +
                ", catalogFileGoogleId='" + catalogFileGoogleId + '\'' +
                ", webContentLink='" + webContentLink + '\'' +
                ", calleeUsername='" + calleeUsername + '\'' +
                '}';
    }
}
