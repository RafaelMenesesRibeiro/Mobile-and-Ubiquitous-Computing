package com.p2p.domain;

public class NewKeyData extends BasicMessage {
	private String calleeUsername;
	private String publicKey;

	public NewKeyData() { }

	public NewKeyData(String calleeUsername, String publicKey) {
		this.calleeUsername = calleeUsername;
		this.publicKey = publicKey;
	}

	public String getCalleeUsername() {
		return calleeUsername;
	}

	public void setCalleeUsername(String calleeUsername) {
		this.calleeUsername = calleeUsername;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
}
