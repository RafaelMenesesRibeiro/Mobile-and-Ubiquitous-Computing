package com.p2p.domain;

public class NewCatalogData extends BasicMessage {
    private String catalogTitle;
    private String calleeUsername;

    public NewCatalogData() { }

    public NewCatalogData(String timestamp, String requestID, String catalogTitle, String calleeUsername) {
        super(timestamp, requestID);
        this.catalogTitle = catalogTitle;
        this.calleeUsername = calleeUsername;
    }

    public String getCatalogTitle() {
        return catalogTitle;
    }

    public void setCatalogTitle(String catalogTitle) {
        this.catalogTitle = catalogTitle;
    }

    public String getCalleeUsername() {
        return calleeUsername;
    }

    public void setCalleeUsername(String calleeUsername) {
        this.calleeUsername = calleeUsername;
    }

}
